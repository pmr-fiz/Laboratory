import my_module
a=int(input())
b=int(input())
print(my_module.add(a,b))