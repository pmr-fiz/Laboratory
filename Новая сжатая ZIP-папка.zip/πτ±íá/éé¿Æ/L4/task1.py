import math
import datetime
print(math.sqrt(17))
print(datetime.datetime.now())