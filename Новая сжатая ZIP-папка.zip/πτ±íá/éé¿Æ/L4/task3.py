from operations import *
a=int(input())
b=int(input())
s=input()
print(chisla.razdeli(a,b))
print(stroki.rev(s))