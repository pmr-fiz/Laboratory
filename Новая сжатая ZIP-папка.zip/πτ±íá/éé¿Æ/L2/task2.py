def describe_person(name, age=30):
    print("Имя:", name)
    print("Возраст:", age)
describe_person("Виталий")
describe_person("Жора", 45)